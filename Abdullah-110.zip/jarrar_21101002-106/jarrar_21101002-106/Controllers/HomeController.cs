﻿using jarrar_21101002_106.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace jarrar_21101002_106.Controllers
{
    public class HomeController : Controller
    {
        Model1 DB = new Model1();
        public ActionResult Indexadmin()
        {
            return View();
        }
        public ActionResult Indexuser()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Cart()
        {
            return View();
        }
        public ActionResult addcart(int? id)
        {
            List<Product> lst;
            if (Session["abc"]==null)
            {
               lst = new List<Product>();
            }
            else
            {
                lst = (List<Product>)Session["abc"];
            }
            lst.Add(DB.Products.Where(p=> p.Product_ID == id).FirstOrDefault());
            lst[lst.Count - 1].qty = 1;
            Session["abc"] = lst;
            return RedirectToAction("Cart");
        }

        public ActionResult plus(int rowno)
        {
            List<Product> lst = (List<Product>)Session["abc"];
            lst[rowno].qty++;
            Session["abc"] = lst;
            return RedirectToAction("Cart");
        }
        public ActionResult minus(int rowno)
        {
            List<Product> lst = (List<Product>)Session["abc"];
            if(lst[rowno].qty>1)
            { 
            lst[rowno].qty--;
            }
            else 
            {
                lst.RemoveAt(rowno);
            }
            Session["abc"] = lst;
            return RedirectToAction("Cart");
        }
        public ActionResult remove(int rowno)
        {
            List<Product> lst = (List<Product>)Session["abc"];
            lst.RemoveAt(rowno);    
            Session["abc"] = lst;
            return RedirectToAction("Cart");
        }
        public ActionResult Shop(int? id)
        {
            Shop s = new Shop();
            s.cat = DB.Categories.ToList();
            if(id == null)
            {
                s.pro = DB.Products.ToList();
            }
            else
            {
                s.pro = DB.Products.Where(p=> p.CAT_FID == id).ToList();
            }
            return View(s);
        }

        public ActionResult Contact()
        {
            return View();
        }

        public ActionResult Feedback()
        {
            return View();
        }

        public ActionResult Login()
        {


            return View();
        }
        [HttpPost]
        public ActionResult Login(Admin a)
        {
            int r = DB.Admins.Where(x => x.Admin_Email == a.Admin_Email && x.Admin_Password == a.Admin_Password).Count();

            if (r == 1)
            {
                ViewBag.Message = "Logged Succeeded.";
                return RedirectToAction("Indexadmin", "Home");
            }
            else
            {
                ViewBag.Message = "Invalid Credentials.";
                return View();
            }
        }
    }
}