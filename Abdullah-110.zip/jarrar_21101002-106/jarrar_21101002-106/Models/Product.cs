namespace jarrar_21101002_106.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;
    using System.Web;

    [Table("Product")]
    public partial class Product
    {
        [Key]
        public int Product_ID { get; set; }

        [Required]
        [StringLength(50)]
        public string Product_Name { get; set; }

        [Required]
        [StringLength(50)]
        public string Product_Description { get; set; }

        [StringLength(50)]
        public string Product_Picture { get; set; }

        [NotMapped]
        public HttpPostedFileBase A_Pic { get; set; }
        [NotMapped]
        public int qty { get; set; }

        [Required]
        [StringLength(50)]
        public string Product_SalePrice { get; set; }

        [Required]
        [StringLength(50)]
        public string Product_PurchasePrice { get; set; }

        public int CAT_FID { get; set; }

        public virtual Category Category { get; set; }
    }
}
