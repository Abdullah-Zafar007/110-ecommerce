﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace jarrar_21101002_106.Models
{
    public class Shop
    {
        public List<Category> cat { get; set; }

        public List<Product> pro { get; set; }
    }
}