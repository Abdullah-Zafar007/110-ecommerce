﻿using System.Web;
using System.Web.Mvc;

namespace jarrar_21101002_106
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
